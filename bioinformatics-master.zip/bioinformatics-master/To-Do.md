# To-Do List for Bioinformatics

- [x] Read the papers about online bioinformatics
- [x] Itemize the topic requirments
- [x] Search for other schools curriculum
- [x] Search for the online education platforms
- [x] Itemize the courses
- [x] Order the courses
- [ ] Prepare a reading list of textbooks
- [ ] Extra reading, most recent papers on bioinformatics technologies
- [ ] Search for all possible fields of studies (For mastery)
