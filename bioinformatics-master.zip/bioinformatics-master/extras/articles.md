# Bioinformatics - Extra Resources

# Articles
1. [So you want to be a computational biologist?](http://www.nature.com/nbt/journal/v31/n11/full/nbt.2740.html) by Nick Loman and Mick Watson (2013).
1. [A Quick Guide for Developing Effective Bioinformatics Programming Skills](http://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1000589) by Joel Dudley and Atul Butte (2009).
1. [Unix Philosophy](https://en.wikipedia.org/wiki/Unix_philosophy)
